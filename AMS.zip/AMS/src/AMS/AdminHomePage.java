/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AMS;
import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

/**
 *
 * @author Atharv Joshi
 */
public class AdminHomePage extends JFrame{
    private JTable requestsTable;
    private DefaultTableModel tableModel;
    private JPanel chartPanel;
    private ConnectionClass connection;
    private JTabbedPane tabbedPane;

    public AdminHomePage() {
        connection = new ConnectionClass();
        setTitle("Admin Dashboard");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        tabbedPane = new JTabbedPane();
        JPanel requestsTab = new JPanel(new BorderLayout());
        String[] columnNames = {"Request ID", "User ID", "Flight Number", "Seat Number", "Status", "Request Type", "Request Date"};
        tableModel = new DefaultTableModel(columnNames, 0);
        requestsTable = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(requestsTable);
        requestsTab.add(tableScrollPane, BorderLayout.CENTER);
        populateRequestsTable();
        tabbedPane.addTab("Requests", requestsTab);
        JPanel statsTab = new JPanel(new BorderLayout());
        chartPanel = new JPanel();
        chartPanel.setLayout(new BoxLayout(chartPanel, BoxLayout.Y_AXIS));
        generateStatisticsCharts();
        statsTab.add(chartPanel, BorderLayout.CENTER);
        tabbedPane.addTab("Statistics", statsTab);
        add(tabbedPane);
        setVisible(true);
    }
    private void populateRequestsTable() {
        try {
            String query = "SELECT * FROM Requests";
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("request_id"),
                        rs.getInt("user_id"),
                        rs.getString("flight_number"),
                        rs.getString("seat_number"),
                        rs.getString("status"),
                        rs.getString("request_type"),
                        rs.getTimestamp("request_date")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching requests", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void generateStatisticsCharts() {
        DefaultCategoryDataset dataset1 = getBookingsPerFlightDataset();
        JFreeChart chart1 = ChartFactory.createBarChart(
                "Bookings Per Flight", "Flight Number", "Number of Bookings",
                dataset1, PlotOrientation.VERTICAL, true, true, false
        );
        chartPanel.add(new ChartPanel(chart1));
        DefaultCategoryDataset dataset3 = getCancellationRequestCountDataset();
        JFreeChart chart3 = ChartFactory.createBarChart(
                "Cancellation Request Count", "Flight Number", "Request Count",
                dataset3, PlotOrientation.VERTICAL, true, true, false
        );
        chartPanel.add(new ChartPanel(chart3));
    }
    private DefaultCategoryDataset getBookingsPerFlightDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try {
            String query = "SELECT f.flight_number, COUNT(b.booking_id) AS booking_count " +
                           "FROM Flights f " +
                           "LEFT JOIN Bookings b ON f.flight_id = b.flight_id " +
                           "GROUP BY f.flight_number";
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                dataset.addValue(rs.getInt("booking_count"), "Bookings", rs.getString("flight_number"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching booking statistics", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return dataset;
    }
    private DefaultCategoryDataset getPaymentMethodDistributionDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try {
            String query = "SELECT payment_method, COUNT(payment_id) AS payment_count " +
                           "FROM Payments " +
                           "GROUP BY payment_method";
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                dataset.addValue(rs.getInt("payment_count"), "Payments", rs.getString("payment_method"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching payment statistics", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return dataset;
    }

    private DefaultCategoryDataset getCancellationRequestCountDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        try {
            String query = "SELECT flight_number, COUNT(request_id) AS request_count " +
                           "FROM Requests " +
                           "GROUP BY flight_number";
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                dataset.addValue(rs.getInt("request_count"), "Requests", rs.getString("flight_number"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching cancellation request statistics", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return dataset;
    }

    public static void main(String[] args) {
        new AdminHomePage();
    }
}
