/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AMS;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

/**
 *
 * @author Atharv Joshi
 */
public class Login extends JFrame implements ActionListener{
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel headlineLabel;
    private JLabel registerLabel;
    private JButton registerButton;  // Register Button
    private int userId;

    public Login(){
       // Set the frame properties
        setTitle("Flight Booking Login");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create a main panel with modern design
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(new Color(240, 248, 255)); // Light blue background

        // Create headline panel
        JPanel headlinePanel = new JPanel();
        headlinePanel.setBackground(new Color(30, 144, 255)); // Dodger blue

        headlineLabel = new JLabel("Ready to Book Your Next Adventure? ");
        headlineLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headlineLabel.setForeground(Color.WHITE);   
        headlineLabel.setBounds(50, 30, 300, 30);
        headlinePanel.add(headlineLabel);
 
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setBackground(new Color(240, 248, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(emailLabel, gbc);

        usernameField = new JTextField(15);
        gbc.gridx = 1;
        formPanel.add(usernameField, gbc);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(passwordLabel, gbc);

        passwordField = new JPasswordField(15);
        gbc.gridx = 1;
        formPanel.add(passwordField, gbc);

        loginButton = new JButton("Login");
        loginButton.setBackground(new Color(30, 144, 255));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.addActionListener(this);
        gbc.gridx = 1;
        gbc.gridy = 2;
        formPanel.add(loginButton, gbc);
        
        // Register Button and label
        registerLabel = new JLabel("New user? Please register before you proceed.");
        registerLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        gbc.gridx = 0;
        gbc.gridy = 3; // Place label below the login button
        gbc.gridwidth = 2; // Span both columns
        formPanel.add(registerLabel, gbc);

        registerButton = new JButton("Register");
        registerButton.setBackground(new Color(30, 144, 255));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFont(new Font("Arial", Font.BOLD, 14));
        // You can add action listener for this button to open registration page
        registerButton.addActionListener(e -> {
            // Action for Register button (for example, opening a registration page)
            JOptionPane.showMessageDialog(this, "Redirecting to registration page.");
        });
        gbc.gridx = 1;
        gbc.gridy = 4; // Place button below the label
        formPanel.add(registerButton, gbc);

    ImageIcon originalIcon = new ImageIcon(getClass().getResource("/Images/airplane-ticket.png"));
    Image scaledImage = originalIcon.getImage().getScaledInstance(250, 250, Image.SCALE_SMOOTH);
    ImageIcon scaledIcon = new ImageIcon(scaledImage);
    JLabel iconLabel = new JLabel(scaledIcon);
    iconLabel.setHorizontalAlignment(JLabel.CENTER);
    iconLabel.setVerticalAlignment(JLabel.CENTER);
    mainPanel.add(headlinePanel, BorderLayout.NORTH);
    mainPanel.add(formPanel, BorderLayout.CENTER);
    mainPanel.add(iconLabel, BorderLayout.SOUTH);
    add(mainPanel);
    setVisible(true);
    }

@Override
public void actionPerformed(ActionEvent e) {
    if (e.getSource() == loginButton) {
        String email = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if ("Admin".equalsIgnoreCase(email) && "123".equals(password)) {
            JOptionPane.showMessageDialog(this, "Welcome Admin! Redirecting to Admin Page.", "Login Successful", JOptionPane.INFORMATION_MESSAGE);
            new AdminHomePage(); // Redirect to Admin page
            this.dispose();
        } else {
            try {
                // Establish connection to the database
                ConnectionClass connection = new ConnectionClass();
                // Modified SQL query to fetch user_id along with email and password
                String query = "SELECT user_id, email, password FROM Users WHERE email = ? AND password = ?";
                PreparedStatement pstmt = connection.Con.prepareStatement(query);
                pstmt.setString(1, email);
                pstmt.setString(2, password);
                
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    int userId = rs.getInt("user_id");  // Fetch the user_id
                    JOptionPane.showMessageDialog(this, "Login Successful! Redirecting to Homepage.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    new Homepage(userId); // Pass userId to Homepage constructor
                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid Email or Password", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "An error occurred while connecting to the database.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } else if (e.getSource() == registerButton) {
        JOptionPane.showMessageDialog(this, "Welcome New User! Redirecting to Registration Page.", "Registration", JOptionPane.INFORMATION_MESSAGE);
        new Register();  // Assuming you have a Register class for new user registration
        this.dispose();
    }
}


    public static void main(String[] args) {
        new Login();
    }
}
