/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AMS;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
/**
 *
 * @author Atharv Joshi
 */
public class Payment extends JFrame{

    private int userId;
    private int flightId;
    private ConnectionClass connection;
    private JComboBox<String> paymentMethodDropdown;
    private JButton confirmPaymentButton, backButton;

    public Payment(int userId, int flightId) {
        this.userId = userId;
        this.flightId = flightId;
        connection = new ConnectionClass();

        setTitle("Payment Page");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(new Color(240, 248, 255));

        JPanel paymentInfoPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        paymentInfoPanel.setBackground(new Color(240, 248, 255));
        paymentInfoPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel flightLabel = new JLabel("Flight ID:");
        JTextField flightField = new JTextField(String.valueOf(flightId));
        flightField.setEditable(false);

        JLabel amountLabel = new JLabel("Amount:");
        JTextField amountField = new JTextField(getFlightPrice(flightId));
        amountField.setEditable(false);

        JLabel paymentMethodLabel = new JLabel("Payment Method:");
        paymentMethodDropdown = new JComboBox<>(new String[]{"Credit Card", "Debit Card", "PayPal"});

        paymentInfoPanel.add(flightLabel);
        paymentInfoPanel.add(flightField);
        paymentInfoPanel.add(amountLabel);
        paymentInfoPanel.add(amountField);
        paymentInfoPanel.add(paymentMethodLabel);
        paymentInfoPanel.add(paymentMethodDropdown);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        confirmPaymentButton = new JButton("Confirm Payment");
        confirmPaymentButton.setBackground(new Color(30, 144, 255));
        confirmPaymentButton.setForeground(Color.WHITE);
        confirmPaymentButton.addActionListener(e -> processPayment(flightId, userId, amountField.getText()));

        backButton = new JButton("Back");
        backButton.setBackground(new Color(30, 144, 255));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> {
            new Flights(userId);
            dispose();
        });
        buttonPanel.add(confirmPaymentButton);
        buttonPanel.add(backButton);
        mainPanel.add(paymentInfoPanel);
        mainPanel.add(buttonPanel);

        add(mainPanel);
        setVisible(true);
    }
    private String getFlightPrice(int flightId) {
        String price = "";
        try {
            String query = "SELECT price FROM Flights WHERE flight_id = ?";
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            pstmt.setInt(1, flightId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                price = String.valueOf(rs.getDouble("price"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching flight price", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return price;
    }
    private void processPayment(int flightId, int userId, String amount) {
        try {
            String bookingQuery = "INSERT INTO Bookings (user_id, flight_id, booking_date, seat_number, status) " +
                                  "VALUES (?, ?, ?, ?, ?)";
            PreparedStatement bookingStmt = connection.Con.prepareStatement(bookingQuery, Statement.RETURN_GENERATED_KEYS);
            bookingStmt.setInt(1, userId);
            bookingStmt.setInt(2, flightId);
            bookingStmt.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
            bookingStmt.setString(4, "A" + (int) (Math.random() * 100)); // Random seat number
            bookingStmt.setString(5, "confirmed");
            bookingStmt.executeUpdate();
            ResultSet generatedKeys = bookingStmt.getGeneratedKeys();
            int bookingId = 0;
            if (generatedKeys.next()) {
                bookingId = generatedKeys.getInt(1);
            }
            String paymentQuery = "INSERT INTO Payments (booking_id, payment_date, amount, payment_method, payment_status) " +
                                  "VALUES (?, ?, ?, ?, ?)";
            PreparedStatement paymentStmt = connection.Con.prepareStatement(paymentQuery);
            paymentStmt.setInt(1, bookingId);
            paymentStmt.setTimestamp(2, Timestamp.valueOf(LocalDateTime.now()));
            paymentStmt.setDouble(3, Double.parseDouble(amount));
            paymentStmt.setString(4, (String) paymentMethodDropdown.getSelectedItem());
            paymentStmt.setString(5, "success");
            paymentStmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Payment successful! Your booking has been confirmed.", "Success", JOptionPane.INFORMATION_MESSAGE);
            new Booking(userId);
            dispose();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error processing payment", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new Payment(1, 2);
    }
}
