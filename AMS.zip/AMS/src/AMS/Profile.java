/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AMS;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
/**
 *
 * @author Atharv Joshi
 */
public class Profile extends JFrame implements ActionListener{
    private JButton myProfileButton, myBookingButton, downloadPassButton, searchFlightsButton, paymentHistoryButton;        
    private JLabel nameLabel, emailLabel, phoneLabel;
    private JTextField nameField, emailField, phoneField;
    private ConnectionClass connection;
    private int userId;

    public Profile(int userId) {
        this.userId = userId;
        setTitle("User Profile");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        connection = new ConnectionClass();
        System.out.println("User id in Profile"+userId);
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(240, 248, 255));

        ImageIcon originalIcon = new ImageIcon(getClass().getResource("/Images/airplane-ticket.png"));
        Image scaledImage = originalIcon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);
        JLabel iconLabel = new JLabel(scaledIcon);
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(30, 144, 255));
        headerPanel.add(iconLabel, BorderLayout.NORTH);
        JLabel headlineLabel = new JLabel("Welcome to Airline Management System", JLabel.CENTER);
        headlineLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headlineLabel.setForeground(Color.WHITE);
        headerPanel.add(headlineLabel, BorderLayout.CENTER);
        JPanel buttonPanel = new JPanel(new GridLayout(0, 1));
        buttonPanel.setBackground(new Color(240, 248, 255));

        myProfileButton = new JButton("My Profile");
        myBookingButton = new JButton("My Booking");
        downloadPassButton = new JButton("Download Boarding Pass");
        paymentHistoryButton = new JButton("Payment History");
        addStyledButton(myProfileButton, buttonPanel);
        addStyledButton(myBookingButton, buttonPanel);
        addStyledButton(downloadPassButton, buttonPanel);
        addStyledButton(paymentHistoryButton, buttonPanel);
        JPanel profilePanel = new JPanel(new GridBagLayout());
        profilePanel.setBackground(new Color(240, 248, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); 
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL; 

        nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0; gbc.gridy = 0; 
        profilePanel.add(nameLabel, gbc);

        nameField = new JTextField(20);
        nameField.setEditable(false);
        gbc.gridx = 1; gbc.gridy = 0;
        profilePanel.add(nameField, gbc);
        emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0; gbc.gridy = 1; 
        profilePanel.add(emailLabel, gbc);

        emailField = new JTextField(20);
        emailField.setEditable(false);  
        gbc.gridx = 1; gbc.gridy = 1; 
        profilePanel.add(emailField, gbc);
        phoneLabel = new JLabel("Phone Number:");
        phoneLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0; gbc.gridy = 2; 
        profilePanel.add(phoneLabel, gbc);

        phoneField = new JTextField(20);
        phoneField.setEditable(false);  
        gbc.gridx = 1; gbc.gridy = 2; 
        profilePanel.add(phoneField, gbc);


        fetchUserDetails();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(profilePanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.WEST);

        add(mainPanel);
        setVisible(true);
    }
    private void addStyledButton(JButton button, JPanel panel) {
        button.setBackground(new Color(30, 144, 255));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.addActionListener(this);
        panel.add(button);
    }

    private void fetchUserDetails() {
        String query = "SELECT name, email, phone_number FROM Users WHERE user_id = ?";
        System.out.println("This is userid"+userId);
        try (PreparedStatement pstmt = connection.Con.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                nameField.setText(rs.getString("name"));
                emailField.setText(rs.getString("email"));
                phoneField.setText(rs.getString("phone_number"));
            } else {
                JOptionPane.showMessageDialog(this, "User not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == paymentHistoryButton) {
            new PaymentHistory(userId);
            this.dispose();
        }
        if (e.getSource() == myProfileButton) {
            new Profile(userId);
            this.dispose();
        }
        if (e.getSource() == myBookingButton) {
            new Booking(userId);
            this.dispose();
        }
        if (e.getSource() == paymentHistoryButton) {
            new PaymentHistory(userId);
            this.dispose();
        }
        if (e.getSource() == downloadPassButton) {
            new BoardingPass(userId);
            this.dispose();
        }
    }
    

    public static void main(String[] args) {
        new Profile(1);
    }

    
}
