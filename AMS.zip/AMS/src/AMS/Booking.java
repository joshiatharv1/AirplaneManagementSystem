/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AMS;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
/**
 *
 * @author Atharv Joshi
 */
public class Booking extends JFrame{
    private JTable flightTable;
    private JTextField seatNumberField, statusField;
    private JButton backButton, sortByDepartureButton, sortByPriceButton, cancelBookingButton;
    private ConnectionClass connection;
    private int userId;
    private DefaultTableModel tableModel;
    public Booking(int userId) {
        this.userId = userId;
        connection = new ConnectionClass();
        setTitle("My Bookings");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(240, 248, 255));
        JLabel headerLabel = new JLabel("My Bookings", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setForeground(Color.WHITE);
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(30, 144, 255));
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        tableModel = new DefaultTableModel(new String[]{
            "Flight ID", "Flight Number", "Origin", "Destination", "Departure Time", "Arrival Time", "Price"
        }, 0);
        flightTable = new JTable(tableModel);
        flightTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane tableScrollPane = new JScrollPane(flightTable);
        tableScrollPane.setPreferredSize(new Dimension(800, 300)); // Set smaller size for the table
        populateTable();
        JPanel sortPanel = new JPanel();
        sortPanel.setBackground(new Color(240, 248, 255));
        sortByDepartureButton = new JButton("Sort by Latest Departure");
        sortByPriceButton = new JButton("Sort by Price (High to Low)");
        sortByDepartureButton.addActionListener(e -> sortTableByDeparture());
        sortByPriceButton.addActionListener(e -> sortTableByPrice());
        sortPanel.add(sortByDepartureButton);
        sortPanel.add(sortByPriceButton);
        JPanel detailsPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        detailsPanel.setBackground(new Color(240, 248, 255));
        detailsPanel.add(new JLabel("Seat Number:"));
        seatNumberField = new JTextField(15);
        seatNumberField.setEditable(false);
        detailsPanel.add(seatNumberField);
        detailsPanel.add(new JLabel("Status:"));
        statusField = new JTextField(15);
        statusField.setEditable(false);
        detailsPanel.add(statusField);
        cancelBookingButton = new JButton("Request Cancellation");
        cancelBookingButton.setBackground(new Color(255, 69, 0));
        cancelBookingButton.setForeground(Color.WHITE);
        cancelBookingButton.addActionListener(e -> requestCancellation());
        flightTable.getSelectionModel().addListSelectionListener(event -> {
            int selectedRow = flightTable.getSelectedRow();
            if (selectedRow != -1) {
                String flightNumber = (String) flightTable.getValueAt(selectedRow, 1);
                fetchBookingDetails(flightNumber);
            }
        });
        backButton = new JButton("Back");
        backButton.setBackground(new Color(30, 144, 255));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> {
            new Homepage(userId);
            dispose();
        });
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);
        mainPanel.add(sortPanel, BorderLayout.SOUTH);
        mainPanel.add(detailsPanel, BorderLayout.SOUTH);
        mainPanel.add(cancelBookingButton, BorderLayout.SOUTH);
        mainPanel.add(backButton, BorderLayout.WEST);

        add(mainPanel);
        setVisible(true);
    }
    private void requestCancellation() {
        int selectedRow = flightTable.getSelectedRow();
        if (selectedRow != -1) {
            String flightNumber = (String) flightTable.getValueAt(selectedRow, 1);
            String seatNumber = seatNumberField.getText();
            String status = statusField.getText();
            try {
                String query = "INSERT INTO Requests (user_id, flight_number, seat_number, status, request_type) " +
                               "VALUES (?, ?, ?, ?, ?)";
                PreparedStatement pstmt = connection.Con.prepareStatement(query);
                pstmt.setInt(1, userId);
                pstmt.setString(2, flightNumber);
                pstmt.setString(3, seatNumber);
                pstmt.setString(4, status);
                pstmt.setString(5, "Cancellation Request");

                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(this, "Cancellation request sent to admin successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error sending cancellation request", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a flight to cancel.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void populateTable() {
        try {
            String query = """
                SELECT f.flight_id, f.flight_number, f.origin, f.destination, 
                       f.departure_time, f.arrival_time, f.price
                FROM Flights f
                JOIN Bookings b ON f.flight_id = b.flight_id
                WHERE b.user_id = ?
            """;
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("flight_id"),
                    rs.getString("flight_number"),
                    rs.getString("origin"),
                    rs.getString("destination"),
                    rs.getString("departure_time"),
                    rs.getString("arrival_time"),
                    rs.getDouble("price")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching flight details", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void sortTableByDeparture() {
        tableModel.setRowCount(0);
        try {
            String query = """
                SELECT f.flight_id, f.flight_number, f.origin, f.destination, 
                       f.departure_time, f.arrival_time, f.price
                FROM Flights f
                JOIN Bookings b ON f.flight_id = b.flight_id
                WHERE b.user_id = ?
                ORDER BY f.departure_time DESC
            """;
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                tableModel.addRow(new Object[] {
                    rs.getInt("flight_id"),
                    rs.getString("flight_number"),
                    rs.getString("origin"),
                    rs.getString("destination"),
                    rs.getString("departure_time"),
                    rs.getString("arrival_time"),
                    rs.getDouble("price")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error sorting by departure time", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void sortTableByPrice() {
        tableModel.setRowCount(0);
        try {
            String query = """
                SELECT f.flight_id, f.flight_number, f.origin, f.destination, 
                       f.departure_time, f.arrival_time, f.price
                FROM Flights f
                JOIN Bookings b ON f.flight_id = b.flight_id
                WHERE b.user_id = ?
                ORDER BY f.price DESC
            """;
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("flight_id"),
                    rs.getString("flight_number"),
                    rs.getString("origin"),
                    rs.getString("destination"),
                    rs.getString("departure_time"),
                    rs.getString("arrival_time"),
                    rs.getDouble("price")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error sorting by price", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void fetchBookingDetails(String flightNumber) {
        try {
            String query = """
                SELECT b.seat_number, b.status
                FROM Bookings b
                JOIN Flights f ON b.flight_id = f.flight_id
                WHERE f.flight_number = ? AND b.user_id = ?
            """;
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            pstmt.setString(1, flightNumber);
            pstmt.setInt(2, userId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                seatNumberField.setText(rs.getString("seat_number"));
                statusField.setText(rs.getString("status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching booking details", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new Booking(1);
    
    }
}
