/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AMS;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

/**
 *
 * @author Atharv Joshi
 */
public class Flights extends JFrame{
    private JComboBox<String> originDropdown, destinationDropdown;
    private JSpinner departureDateSpinner;
    private JButton searchButton, paymentButton, backButton;
    private JTable flightsTable;
    private DefaultTableModel tableModel;
    private int userId;
    private ConnectionClass connection;

    public Flights(int userId) {
        this.userId = userId;
        connection = new ConnectionClass();
        setTitle("Search Flights");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(240, 248, 255));
        JPanel searchPanel = new JPanel(new GridBagLayout());
        searchPanel.setBackground(new Color(240, 248, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        JLabel originLabel = new JLabel("Origin:");
        originDropdown = new JComboBox<>(getCities("origin"));
        gbc.gridx = 0; gbc.gridy = 0;
        searchPanel.add(originLabel, gbc);
        gbc.gridx = 1;
        searchPanel.add(originDropdown, gbc);
        JLabel destinationLabel = new JLabel("Destination:");
        destinationDropdown = new JComboBox<>(getCities("destination"));
        gbc.gridx = 2; gbc.gridy = 0;
        searchPanel.add(destinationLabel, gbc);
        gbc.gridx = 3;
        searchPanel.add(destinationDropdown, gbc);
        JLabel dateLabel = new JLabel("Departure Date:");
        departureDateSpinner = new JSpinner(new SpinnerDateModel());
        departureDateSpinner.setEditor(new JSpinner.DateEditor(departureDateSpinner, "yyyy-MM-dd"));
        departureDateSpinner.setPreferredSize(new Dimension(120, 25));
        gbc.gridx = 4; gbc.gridy = 0;
        searchPanel.add(dateLabel, gbc);
        gbc.gridx = 5;
        searchPanel.add(departureDateSpinner, gbc);
        searchButton = new JButton("Search Flights");
        searchButton.setBackground(new Color(30, 144, 255));
        searchButton.setForeground(Color.WHITE);
        searchButton.addActionListener(e -> searchFlights());
        gbc.gridx = 6; gbc.gridy = 0;
        searchPanel.add(searchButton, gbc);

        mainPanel.add(searchPanel, BorderLayout.NORTH);
        String[] columns = {"Flight ID", "Flight Number", "Origin", "Destination", "Departure Time", "Arrival Time", "Price"};
        tableModel = new DefaultTableModel(columns, 0);
        flightsTable = new JTable(tableModel);
        flightsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane tableScrollPane = new JScrollPane(flightsTable);
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        paymentButton = new JButton("Make Payment");
        paymentButton.setBackground(new Color(30, 144, 255));
        paymentButton.setForeground(Color.WHITE);
        paymentButton.setEnabled(false);
        paymentButton.addActionListener(e -> proceedToPayment());

        backButton = new JButton("Back");
        backButton.setBackground(new Color(30, 144, 255));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> {
            new Homepage(userId);
            dispose();
        });

        flightsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && flightsTable.getSelectedRow() != -1) {
                paymentButton.setEnabled(true); // Enable payment button when a row is selected
            }
        });

        bottomPanel.add(backButton);
        bottomPanel.add(paymentButton);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        add(mainPanel);
        setVisible(true);
    }
    private String[] getCities(String column) {
        try {
            String query = "SELECT DISTINCT " + column + " FROM Flights";
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            java.util.List<String> cities = new java.util.ArrayList<>();
            while (rs.next()) {
                cities.add(rs.getString(column));
            }
            return cities.toArray(new String[0]);
        } catch (SQLException e) {
            e.printStackTrace();
            return new String[0];
        }
    }

    private void searchFlights() {
        String origin = (String) originDropdown.getSelectedItem();
        String destination = (String) destinationDropdown.getSelectedItem();
        String departureDate = new java.text.SimpleDateFormat("yyyy-MM-dd").format(departureDateSpinner.getValue());

        try {
            String query = """
                SELECT flight_id, flight_number, origin, destination, departure_time, arrival_time, price 
                FROM Flights 
                WHERE origin = ? AND destination = ? AND DATE(departure_time) = ?
            """;
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            pstmt.setString(1, origin);
            pstmt.setString(2, destination);
            pstmt.setString(3, departureDate);

            ResultSet rs = pstmt.executeQuery();
            tableModel.setRowCount(0); // Clear existing rows
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("flight_id"),
                        rs.getString("flight_number"),
                        rs.getString("origin"),
                        rs.getString("destination"),
                        rs.getString("departure_time"),
                        rs.getString("arrival_time"),
                        rs.getDouble("price")
                });
            }

            if (tableModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No flights found for the selected criteria.", "No Results", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching flights.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void proceedToPayment() {
        int selectedRow = flightsTable.getSelectedRow();
        if (selectedRow != -1) {
            int flightId = (int) tableModel.getValueAt(selectedRow, 0);
            new Payment(userId, flightId);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a flight.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new Flights(1);
    }
}
