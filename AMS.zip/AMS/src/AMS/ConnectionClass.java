/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AMS;
import java.sql.*;
/**
 *
 * @author Atharv Joshi
 */
public class ConnectionClass {
    Connection Con;
    Statement St;
    
    ConnectionClass(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Con=DriverManager.getConnection("jdbc:mysql:///ams","root","root");
            St=Con.createStatement();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String gg[]){
        new ConnectionClass();
    }
}
