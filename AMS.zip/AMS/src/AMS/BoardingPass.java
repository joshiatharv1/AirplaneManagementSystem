/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AMS;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.*;
/**
 *
 * @author Atharv Joshi
 */
public class BoardingPass extends JFrame{
    private JComboBox<String> bookingDropdown;
    private JButton createBoardingPassButton, saveButton, backButton;
    private JPanel boardingPassPanel;
    private int userId;
    private ConnectionClass connection;

    public BoardingPass(int userId) {
        this.userId = userId;
        connection = new ConnectionClass();
        setTitle("Create Boarding Pass");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(new Color(240, 248, 255));
        JPanel topPanel = new JPanel();
        topPanel.setBackground(new Color(240, 248, 255));
        topPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel selectBookingLabel = new JLabel("Select Booking ID:");
        bookingDropdown = new JComboBox<>();
        loadBookings();
        createBoardingPassButton = new JButton("Generate Boarding Pass");
        createBoardingPassButton.addActionListener(e -> generateBoardingPass());
        topPanel.add(selectBookingLabel);
        topPanel.add(bookingDropdown);
        topPanel.add(createBoardingPassButton);
        backButton = new JButton("Back");
        backButton.setBackground(new Color(30, 144, 255));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> {
            new Homepage(userId);
            dispose();
        });

        topPanel.add(backButton);
        boardingPassPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                setBackground(Color.WHITE);
            }
        };
        boardingPassPanel.setPreferredSize(new Dimension(600, 300));
        boardingPassPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        saveButton = new JButton("Save as PDF/Image");
        saveButton.setEnabled(false);
        saveButton.addActionListener(e -> saveAsImageOrPDF());
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(boardingPassPanel, BorderLayout.CENTER);
        mainPanel.add(saveButton, BorderLayout.SOUTH);
        add(mainPanel);
        setVisible(true);
    }
    private void loadBookings() {
        try {
            String query = "SELECT booking_id FROM Bookings WHERE user_id = ?";
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                bookingDropdown.addItem(rs.getString("booking_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading bookings", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void generateBoardingPass() {
        try {
            String selectedBookingId = (String) bookingDropdown.getSelectedItem();
            if (selectedBookingId == null) {
                JOptionPane.showMessageDialog(this, "Please select a booking", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Query to fetch flight and booking details for selected booking_id
            String query = """
                SELECT f.flight_number, f.origin, f.destination, f.departure_time, f.arrival_time, f.price, 
                       b.seat_number, b.status
                FROM Flights f
                JOIN Bookings b ON f.flight_id = b.flight_id
                WHERE b.booking_id = ? AND b.user_id = ?
            """;
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            pstmt.setString(1, selectedBookingId);
            pstmt.setInt(2, userId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String flightNumber = rs.getString("flight_number");
                String origin = rs.getString("origin");
                String destination = rs.getString("destination");
                String departureTime = rs.getString("departure_time");
                String arrivalTime = rs.getString("arrival_time");
                double price = rs.getDouble("price");
                String seatNumber = rs.getString("seat_number");
                String status = rs.getString("status");
                Graphics g = boardingPassPanel.getGraphics();
                g.setColor(Color.BLACK);
                g.setFont(new Font("Arial", Font.BOLD, 16));
                g.drawString("Boarding Pass", 250, 30);
                g.setFont(new Font("Arial", Font.PLAIN, 14));
                g.drawString("Flight Number: " + flightNumber, 50, 70);
                g.drawString("Origin: " + origin, 50, 100);
                g.drawString("Destination: " + destination, 50, 130);
                g.drawString("Departure Time: " + departureTime, 50, 160);
                g.drawString("Arrival Time: " + arrivalTime, 50, 190);
                g.drawString("Seat Number: " + seatNumber, 50, 220);
                g.drawString("Booking Status: " + status, 50, 250);
                g.drawString("Price: $" + price, 50, 280);

                saveButton.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "No data found for the selected booking.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error generating boarding pass", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void saveAsImageOrPDF() {
        try {
            BufferedImage image = new BufferedImage(boardingPassPanel.getWidth(), boardingPassPanel.getHeight(), BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = image.createGraphics();
            boardingPassPanel.paint(g2d);
            g2d.dispose();
            File outputfile = new File("BoardingPass.png");
            ImageIO.write(image, "png", outputfile);

            JOptionPane.showMessageDialog(this, "Boarding pass saved as an image successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving boarding pass", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    public static void main(String[] args) {
        new BoardingPass(1);
    }
}
