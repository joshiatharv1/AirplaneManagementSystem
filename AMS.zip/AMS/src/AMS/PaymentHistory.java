/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AMS;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
/**
 *
 * @author Atharv Joshi
 */
public class PaymentHistory extends JFrame{
        private JTable paymentTable;
    private JTextField bookingIdField, paymentDateField, amountField, methodField, statusField;
    private JButton backButton;
    private DefaultTableModel tableModel;
    private int userId;
    private ConnectionClass connection;

    public PaymentHistory(int userId) {
        this.userId = userId;
        connection = new ConnectionClass();
        setTitle("Payment History");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(240, 248, 255));
        JLabel headerLabel = new JLabel("Payment History", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setForeground(Color.WHITE);
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(30, 144, 255));
        headerPanel.add(headerLabel, BorderLayout.CENTER);
        tableModel = new DefaultTableModel(new String[]{
            "Booking ID", "Payment Date", "Payment Method", "Amount", "Status"
        }, 0);
        paymentTable = new JTable(tableModel);
        paymentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane tableScrollPane = new JScrollPane(paymentTable);
        tableScrollPane.setPreferredSize(new Dimension(800, 300)); // Set smaller size for the table
        populateTable();
        JPanel detailsPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        detailsPanel.setBackground(new Color(240, 248, 255));
        detailsPanel.add(new JLabel("Booking ID:"));
        bookingIdField = new JTextField(15);
        bookingIdField.setEditable(false);
        detailsPanel.add(bookingIdField);

        detailsPanel.add(new JLabel("Payment Date:"));
        paymentDateField = new JTextField(15);
        paymentDateField.setEditable(false);
        detailsPanel.add(paymentDateField);

        detailsPanel.add(new JLabel("Amount:"));
        amountField = new JTextField(15);
        amountField.setEditable(false);
        detailsPanel.add(amountField);

        detailsPanel.add(new JLabel("Payment Method:"));
        methodField = new JTextField(15);
        methodField.setEditable(false);
        detailsPanel.add(methodField);

        detailsPanel.add(new JLabel("Status:"));
        statusField = new JTextField(15);
        statusField.setEditable(false);
        detailsPanel.add(statusField);
        paymentTable.getSelectionModel().addListSelectionListener(event -> {
            int selectedRow = paymentTable.getSelectedRow();
            if (selectedRow != -1) {
                int bookingId = (Integer) paymentTable.getValueAt(selectedRow, 0);
                fetchPaymentDetails(bookingId);
            }
        });

        backButton = new JButton("Back");
        backButton.setBackground(new Color(30, 144, 255));
        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(e -> {
            new Homepage(userId);
            dispose();
        });

        // Add Components to Main Panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);            
        mainPanel.add(tableScrollPane, BorderLayout.CENTER);       
        mainPanel.add(detailsPanel, BorderLayout.SOUTH);           
        mainPanel.add(backButton, BorderLayout.WEST);              

        add(mainPanel);
        setVisible(true);
    }

    private void populateTable() {
        try {
            String query = """
                SELECT b.booking_id, p.payment_date, p.payment_method, p.amount, p.payment_status
                FROM Payments p
                JOIN Bookings b ON p.booking_id = b.booking_id
                WHERE b.user_id = ?
            """;
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("booking_id"),
                    rs.getString("payment_date"),
                    rs.getString("payment_method"),
                    rs.getDouble("amount"),
                    rs.getString("payment_status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching payment details", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void fetchPaymentDetails(int bookingId) {
        try {
            String query = """
                SELECT p.payment_date, p.amount, p.payment_method, p.payment_status
                FROM Payments p
                WHERE p.booking_id = ?
            """;
            PreparedStatement pstmt = connection.Con.prepareStatement(query);
            pstmt.setInt(1, bookingId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                paymentDateField.setText(rs.getString("payment_date"));
                amountField.setText(String.valueOf(rs.getDouble("amount")));
                methodField.setText(rs.getString("payment_method"));
                statusField.setText(rs.getString("payment_status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching payment details", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new PaymentHistory(1);
    }
}
